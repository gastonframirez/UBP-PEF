#include <stdio.h>

int main () {
  float x, y;

  x = 1.25e8;

  y = x + 7.5e-3;

  if (x == y)
    printf("Las variables son iguales\n");
  else
    printf("Las variables son iguales\n");

  return 0;
}
