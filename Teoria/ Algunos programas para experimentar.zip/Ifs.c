#include <stdio.h>
 
int main() {
  int a=1, b=2;
  if (a == 1) {
    printf("a = 1\n");
  }
  else {
    printf("a != 1\n");
  }
  if (b == 1) {
    printf("b = 1\n");
  }
  else {
    printf("b != 1\n");
  }
  
  return 0;
}
